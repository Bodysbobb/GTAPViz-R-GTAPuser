rm(list = ls())
cat("Check the README: see section 1.Project Setup")

# 1. Project Setup -----------------------------------------------------------
# See - `1. Project Parameters`

# 1.1
project.folder <- "D:/One Drive/OneDrive - purdue.edu/JGEA Paper/GTAPViz/users"    

# 1.2
experiment <- c("IncreaseTar10", "IncreaseTar50", "ReduceTar20") 

# 1.3
sl4_suffix <- ""     
har_suffix <- "-WEL"

# 1.4
process_sl4_vars <- "sl4map"  # Leave it like this for default
process_har_vars <- "harmap"  # Leave it like this for default


# 2. Output Setup ------------------------------------------------------------
# See - `2. Output Formatting Parameters`

# 2.1
mapping_info <- "Mix"     

# 2.2
csv.output <- "No"         
stata.output <- "No"
r.output <- "No"
txt.output <- "No"

# 2.3
plot_data <- TRUE  

# 2.4
sl4_convert_unit <- c("mil2bil") 
har_convert_unit <- c("mil2bil")
decimals <- 2

# 2.5
rename_columns <- TRUE

# 2.6
subtotal_level <- FALSE

# 2.7
add_scenario_ranking <- TRUE


# DO NOT CHANGE BELOW THIS POINT ------------------------------------------
source(paste0(project.folder,"/src/!README/src_help/!help_function.R"))

