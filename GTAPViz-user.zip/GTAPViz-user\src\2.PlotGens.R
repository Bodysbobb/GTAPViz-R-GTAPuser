# Plot Configurations
# Plot Config Manuscript: https://pattawee.shinyapps.io/gtapviz-advanced-plot-configs/
cat("Check the README: see section 2. Plotting — it provides multiple 
    code formats ready for copy and paste!")


# Output Directory --------------------------------------------------------
# You may define a custom output folder to create separate directories for each plot.
# or set it to default: output.folder.pic <- output.folder
output.folder <- output.folder  

# 1. Comparison Plot -----------------------------------------------------

# For help function use: ?comparison_plot
comparison.data <- sl4.plot.data[["REG"]]   # Replace with your actual dataframe name

default_compare.plot <- comparison_plot(  # ! Do not change this line
  data                      = comparison.data,
  x_axis_from               = "Region",         # Column used for the x-axis
  filter_var                = list(Variable = c("qgdp")),             # Optional column to filter data based on x-axis
  split_by                  = "Variable",       # Column(s) used to split data into separate plots
  panel_var                 = "Experiment",     # Column used for paneling (faceting)
  invert_axis               = TRUE,            # Whether to invert the panel (facet) order
  separate_figure           = FALSE,            # Whether to generate a separate figure for each panel
  var_name_by_description   = FALSE,            # Use description as variable name
  add_var_info              = FALSE,            # Add variable code in parentheses
  export_picture            = TRUE,             # Export as image
  export_as_pdf             = "merged",           # Export the plots as PDF. Use "merged" to combine all plots into one PDF
  output_path               = output.folder,
  
  # Output Configurations
  ## Try adjusting widgth and height if output is too dense, too small, or not displayed properly
  export_config = create_export_config(
    width  = 28,
    height = 15
  ),
  
  # Some Plot Style Configurations
  plot_style_config = create_plot_style(
    title_format = create_title_format(
      type = "dynamic",                         # dynamic allows use of {Description}
      text = "Impacts on {Description}",
      sep  = ""
    ),
    all_font_size = 1,
    panel_rows    = 1,
    panel_cols    = NULL,
    color_tone    = "gtap"
  )
)


# 2. Detail Plot ---------------------------------------------------------

# For help function use: ?detail_plot
detail.data <- sl4.plot.data[["COMM*REG"]]  # Replace with your actual dataframe

default_detail <- detail_plot(
  data                      = detail.data,
  x_axis_from               = "Commodity",      # Column used for the x-axis
  filter_var                = NULL,             # Optional column to filter data based on x-axis
  split_by                  = "Region",         # Column(s) used to split data into separate plots (e.g., one plot per variable)
  panel_var                 = "Experiment",     # Column used for paneling (faceting)
  top_impact                = 5,             # Optionally limit to top-N most impactful entries per panel (e.g., top_impact = 10)
  invert_axis              = TRUE,             # Whether to invert the panel (facet) order
  separate_figure           = FALSE,            # Whether to generate a separate figure for each panel
  var_name_by_description   = TRUE,             # Use the description as the variable name (e.g., qgdp becomes Real GDP)
  add_var_info              = FALSE,            # Add variable code in parentheses (e.g., Real GDP (qgdp))
  export_picture            = TRUE,            # Export the plots as image files
  export_as_pdf             = FALSE,            # Export the plots as PDF. Use "merged" to combine all plots into one PDF
  output_path               = output.folder,
  
  # Output Configurations
  ## Try adjusting widgth and height if output is too dense, too small, or not displayed properly     
  export_config = create_export_config(  
    width  = 23,              # Width of the output plot in inches
    height = 9                # Height of the output plot in inches
  ),
  
  plot_style_config = create_plot_style(
    title_format = create_title_format(
      type = "prefix",        # option: standard (default), prefix, suffix, full, dynamic
      text = "Change in",
      sep  = " - "
    ),
    positive_color = "#2E8B57",  # Color for positive values
    negative_color = "#CD5C5C",  # Color for negative values
    all_font_size  = 1.1,        # Scale for all font sizes in the plot 
    panel_rows     = 1,          # Number of rows for the panel layout, NULL for automatic calculation  
    panel_cols     = NULL        # Number of columns for the panel layout, NULL for automatic calculation
  )
)


# 3. Stack Plot ----------------------------------------------------------

# For help function use: ?stack_plot
stack.data <- har.plot.data[["A"]]  # Replace with your actual dataframe

stack_plot(
  data                      = stack.data,
  x_axis_from               = "Region",        # Column used for the x-axis
  filter_var                = NULL,            # Optional column to filter data based on x-axis
  stack_value_from          = "COLUMN",        # Column that defines the components of the stack plot
  show_total                = TRUE,            # Show the total value label in the stack plot
  unstack_plot              = FALSE,           # If TRUE, unstack the bars and display them separately (comparison style)
  split_by                  = FALSE,           # Column(s) used to split data into separate plots. FALSE disables splitting
  panel_var                 = "Experiment",    # Column used for paneling (faceting)
  top_impact                = NULL,            # Optionally limit to top-N most impactful entries per panel
  invert_axis              = FALSE,           # Whether to invert the panel (facet) order
  separate_figure           = FALSE,           # Whether to generate a separate figure for each panel
  var_name_by_description   = TRUE,            # Use the description as the variable name (e.g., qgdp becomes Real GDP)
  add_var_info              = FALSE,           # Add variable code in parentheses (e.g., Real GDP (qgdp))
  export_picture            = TRUE,           # Export the plots as image files
  export_as_pdf             = "merged",           # Export the plots as PDF. Use "merged" to combine all plots into one PDF
  output_path               = output.folder,
  
  # Output Configurations
  ## Try adjusting widgth and height if output is too dense, too small, or not displayed properly     
  export_config = create_export_config(
    width  = 28,             # Width of the output plot in inches
    height = 15              # Height of the output plot in inches
  ),
  
  plot_style_config = create_plot_style(
    title_format = create_title_format(
      type = "full",         # option: standard (default), prefix, suffix, full, dynamic
      text = "Welfare Decomposition",
      sep  = ""
    ),
    color_tone    = "purdue",   # Color palette for the plot
    all_font_size = 1,          # Scale for all font sizes in the plot 
    panel_rows    = 1,          # Number of rows for the panel layout, NULL for automatic calculation  
    panel_cols    = NULL        # Number of columns for the panel layout, NULL for automatic calculation  
  )
)