# Help functions ----------------------------------------------------------
assign_default <- function(var_name, default_value, treat_null_as_missing = TRUE, treat_empty_string_as_missing = FALSE) {
  if (!exists(var_name)) {
    return(default_value)
  }
  
  val <- get(var_name)
  
  if (is.na(val)) return(default_value)
  if (treat_null_as_missing && is.null(val)) return(default_value)
  if (treat_empty_string_as_missing && identical(val, "")) return(default_value)
  
  return(val)
}

# Preparing Input ---------------------------------------------------------
# Install packagfees if not already installed
invisible(lapply(c("readxl", "GTAPViz"), function(pkg) { if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg); library(pkg, character.only = TRUE) }))


# 1. Default Directory
input.folder <- paste0(project.folder, "/in")
map.folder <- paste0(project.folder, "/map")
output.folder <- paste0(project.folder, "/out")

# 2. Default Input Files
sl4map <- readxl::read_xlsx(paste0(map.folder, "/OutputMapping.xlsx"), sheet = "SL4File")
harmap <- readxl::read_xlsx(paste0(map.folder, "/OutputMapping.xlsx"), sheet = "HARFile")
filter.map <- readxl::read_xlsx(paste0(map.folder, "/OutputMapping.xlsx"), sheet = "FilterData")

# 3. Suffix for Input Files
sl4_suffix <- assign_default("sl4_suffix", "", treat_empty_string_as_missing = FALSE)
har_suffix <- assign_default("har_suffix", "", treat_empty_string_as_missing = FALSE)

# 4. Processing variables
if (!exists("process_sl4_vars") || is.null(process_sl4_vars) || identical(process_sl4_vars, sl4map)) {
  process_sl4_vars <- sl4map
}

if (!exists("process_har_vars") || is.null(process_har_vars) || identical(process_har_vars, harmap)) {
  process_har_vars <- harmap
}


# 5. Filter Data
selected_regions <- if (exists("filter.map") && length(filter.map$Region) > 0) filter.map$Region else NULL
selected_sector  <- if (exists("filter.map") && length(filter.map$Sector) > 0) filter.map$Sector else NULL

# 6. Converting Units & Rename Columns
sl4_convert_unit <- assign_default("sl4_convert_unit", NULL)
har_convert_unit <- assign_default("har_convert_unit", NULL)
decimals <- assign_default("decimals", 4)
rename_columns <- assign_default("rename_columns", TRUE)

# 7. Scenario Number Labels Column
add_scenario_ranking <- assign_default("add_scenario_ranking", FALSE)

# 8. Data Extraction Methods
## Set default values if missing
sl4_extract_method <- assign_default("sl4_extract_method", "get_data_by_dims")
har_extract_method <- assign_default("har_extract_method", "get_data_by_var")

## Check if priority is missing when using group_data_by_dims
if (sl4_extract_method == "group_data_by_dims") {
  if (!exists("sl4_priority") || is.null(sl4_priority) || sl4_priority == "") {
    stop("Please define 'sl4_priority' for sl4_extract_method = 'group_data_by_dims'")
  }
}

if (har_extract_method == "group_data_by_dims") {
  if (!exists("har_priority") || is.null(har_priority) || har_priority == "") {
    stop("Please define 'har_priority' for har_extract_method = 'group_data_by_dims'")
  }
}

# Extracting Data ---------------------------------------------------------

auto_gtap_data(
  # Input Main File Names
  experiment = experiment, 
  
  # Input File Suffixes
  sl4_suffix = sl4_suffix,
  har_suffix = har_suffix,
  
  # Directories
  input_path = input.folder,
  output_path = output.folder,
  
  # Variable Selection
  process_sl4_vars = sl4map, 
  process_har_vars = harmap,
  
  # Description and Unit Mapping (if `mapping_info` is set to "Yes" or "Mix")
  mapping_info = mapping_info,
  sl4_mapping_info = sl4map,
  har_mapping_info = harmap,
  rename_columns = rename_columns,
  
  # Convert units (see `?convert_units`)
  sl4_convert_unit = sl4_convert_unit,
  har_convert_unit = har_convert_unit,
  
  # Region and Sector Filtering
  region_select = selected_regions,
  sector_select = selected_sector,
  
  # Data Extraction Process
  sl4_extract_method = sl4_extract_method,
  har_extract_method = har_extract_method,
  subtotal_level = subtotal_level,
  
  # If using `"group_data_by_dims"`, a `priority_list` is required. See `?HARplus::group_data_by_dims`.
  sl4_priority = sl4_priority,
  har_priority = har_priority,
  
  # Adding Scenario Ranking
  add_scenario_ranking = add_scenario_ranking,
  
  # Output Formats
  plot_data = plot_data,
  output_formats = list(
    "csv" = csv.output,
    "stata" = stata.output,
    "rds" = r.output,
    "txt" = txt.output
  ),
  
  # Output Names for Plot Data
  sl4_output_name = "sl4.plot.data",
  har_output_name = "har.plot.data",
  macro_output_name = "GTAPMacro"
)

rm(filter.map, sl4map, harmap)