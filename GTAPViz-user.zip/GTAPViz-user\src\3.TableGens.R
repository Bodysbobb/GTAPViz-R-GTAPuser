# Table Outputs
# Table Config Manuscript: https://pattawee.shinyapps.io/gtapviz-advanced-table-configs/


# Table Types ---------------------------------------------------------------
# You may define a custom output folder to create separate directories for each table.
# or set it to default: output.folder.table <- output.folder
output.folder <- output.folder


# 1. Structured Report Table ----------------------------------------------
data_list <- sl4.plot.data   

report_table( # DO NOT CHANGE THIS FUCNTION NAME; MAKE YOUR CHANGES BELOW
  data_list = data_list,
  
  pivot_col = list( # See manual or run `?report_table` for more details
    REG = "Variable", 
    'COMM*REG' = "Commodity"
  ),
  
  group_by = list( # See manual or run `?report_table` for more details
    REG = list("Experiment", "Region"),
    'COMM*REG' = list("Experiment", "Variable", "Region")
  ),
  
  rename_cols = list("Experiment" = "Scenario"), 
  total_column = FALSE,
  decimal = 4,
  subtotal_level = FALSE,
  repeat_label = FALSE,
  include_units = TRUE,
  
  var_name_by_description = TRUE,
  add_var_info = TRUE,
  add_group_line = FALSE,
  
  separate_sheet_by = "Unit",
  export_table = TRUE,
  output_path = output.folder,
  separate_file = FALSE,
  workbook_name = "Comparison Table 1D"
)


# 2 Pivot Table with Filter ---------------------------------------------
data_pivot_table <- sl4.plot.data[["REG"]]  

pivot_table_with_filter( # DO NOT CHANGE THIS FUCNTION NAME; MAKE YOUR CHANGES BELOW
  data = data_pivot_table,
  filter = c("Variable", "Unit"),    # Allow filtering by variable type and unit
  rows = c("Region"),      # Regions and sectors as row fields
  cols = c("Experiment"),           # Experiments as column fields
  data_fields = "Value",            # Values to be aggregated
  raw_sheet_name = "Raw_Data",     # Sheet name for raw data
  pivot_sheet_name = "Sector_Pivot", # Sheet name for pivot table
  dims = "A3",                      # Starting cell for pivot table
  export_table = TRUE,
  output_path = output.folder,
  workbook_name = "Sectoral_Impact_Analysis.xlsx"
)
